const principal = document.querySelector("#juegos");

const url = "../JSON/videojuegos.json";

async function cargarJSON() {
  try {
    const response = await fetch(url);
    const data = await response.json();

    generaListaJuegos(data);
  } catch (error) {
    console.error("Error cargando el JSON:", error);
  }
}

cargarJSON();

function generaListaJuegos(datosJuegos) {
  datosJuegos.forEach((juego) => {
    const juegoSection = document.createElement("section");
    const JuegoNombre = document.createElement("h3");
    const JuegoEstudio = document.createElement("h3");
    const JuegoAnyio = document.createElement("h3");

    const JuegoPlataformasDiv = document.createElement("div");
    JuegoPlataformasDiv.setAttribute("id", "plataformas");
    const JuegoPlataforma1 = document.createElement("span");
    const JuegoPlataforma2 = document.createElement("span");
    const JuegoPlataforma3 = document.createElement("span");

    const JuegoArticle = document.createElement("article");
    const JuegoDivValoraciones = document.createElement("div");
    const JuegoValoracion1 = document.createElement("div");
    const JuegoValoracion2 = document.createElement("div");
    const JuegoValoracion3 = document.createElement("div");
    const JuegoValoracion4 = document.createElement("div");

    NombreJuego = document.createTextNode(juego.nombre);
    EstudioJuego = document.createTextNode(juego.estudio);
    AnyioJuego = document.createTextNode(juego.Fecha_Lanzamiento);

    JuegoNombre.append(NombreJuego);
    JuegoEstudio.append(EstudioJuego);
    JuegoAnyio.append(AnyioJuego);

    juegoSection.append(JuegoNombre, JuegoEstudio, JuegoAnyio);

    for (let i = 0; i < juego.Plataformas.length; i++) {
      const span = document.createElement("span");

      const textoPlataforma = document.createTextNode(juego.Plataformas[i]);

      span.append(textoPlataforma);

      JuegoPlataformasDiv.append(span);
    }

    JuegoArticle.append(JuegoDivValoraciones);
    juegoSection.append(JuegoArticle);

    for (let i = 0; i < juego.Valoraciones.length; i++) {
      const div = document.createElement("div");

      const textoUsuario = document.createTextNode(juego.Valoraciones[i].usuario);
      const textoJugabilidad = document.createTextNode(juego.Valoraciones[i].puntuacion_Jugabilidad);
      const textoDiseño = document.createTextNode(juego.Valoraciones[i].puntuacion_Diseño);
      const textoHistoria = document.createTextNode(juego.Valoraciones[i].puntuacion_Historia);

      div.append(textoUsuario, textoJugabilidad, textoDiseño, textoHistoria);
      JuegoDivValoraciones.append(div);
    }

    JuegoArticle.append(JuegoDivValoraciones);
    juegoSection.append(JuegoArticle);

    principal.append(juegoSection);
  });
}
